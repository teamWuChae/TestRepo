package com.example.rhythmproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class GameStartActivity extends AppCompatActivity {

    private Button SotbBtn;
    private Button CSexBtn;
    private Button ESexBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_start);

        SotbBtn = findViewById(R.id.SotbBtn);

        SotbBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(GameStartActivity.this, SotbReady.class);
                startActivity(intent);
            }
        });

        CSexBtn = findViewById(R.id.CSexBtn);

        CSexBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(GameStartActivity.this, CSexReady.class);
                startActivity(intent);
            }
        });

        ESexBtn = findViewById(R.id.ESexBtn);

        ESexBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(GameStartActivity.this, ESexReady.class);
                startActivity(intent);
            }
        });



    }
}